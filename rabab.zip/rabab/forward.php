<?php include('connect.php'); ?>
<?php 
	
    if(isset($_GET['direction']))
    {
        $direction = $_GET['direction'];

        if($direction != "delete")
        {
            $udregistrationsql = "INSERT INTO `direction` (`id`, `dirname`) VALUES (NULL, '$direction');";
            $resReg = mysqli_query($conn,$udregistrationsql);
            $count = mysqli_affected_rows($conn);
        }
    }
?>

<!DOCTYPE html>
<html>
    <head> 
        <link rel="stylesheet" href="style.css" />
    </head>

<body contenteditable="false">

 

<h1>U</h1>

<br>
<br>
<br>
    
    <br>
<br>
    <br>

<br>
<br>
<a href="forward.php" class="button" style="width:10%;">Forward</a> 
<br>
<br>
<a href="l.php?direction=L" class="button1" style="width:10%;">Left</a> 
<a href="s.php?direction=Delete" class="button4" style="width:10%;">Stop</a> 
<a href="r.php?direction=R" class="button2" style="width:10%;">Right</a>
<br>
<br>
<a href="backward.php" class="button3" style="width:10%;">Backward</a> 

</body> </html>