<?php include('connect.php'); ?>
<?php
	
    if(isset($_GET['direction']))
    {
            $udregistrationsql = "DELETE from `direction`";
            $resReg = mysqli_query($conn,$udregistrationsql);
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css" />
    </head>

<body contenteditable="false">

<h1>S</h1>

<br>
<br>
<br>

    <br>
<br>
    <br>

<br>
<br>
<a href="forward.php?direction=U" class="button" style="width:10%;">Forward</a>
<br>
<br>
<a href="l.php?direction=L" class="button1" style="width:10%;">Left</a>
<a href="s.php?direction=Delete" class="button4" style="width:10%;">Stop</a>
<a href="r.php?direction=R" class="button2" style="width:10%;">Right</a>
<br>
<br>
<a href="backward.php?direction=D" class="button3" style="width:10%;">Backward</a>

</body> </html>
