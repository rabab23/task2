<?php 
	error_reporting(E_ERROR);
	$conn = mysqli_connect('localhost','root','root123456','shaima');
?>